package ch.epfl.rigel.bonus;

import ch.epfl.rigel.coordinates.GeographicCoordinates;
import ch.epfl.rigel.math.Angle;
import com.interactivemesh.jfx.importer.ImportException;
import com.interactivemesh.jfx.importer.obj.ObjModelImporter;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.geometry.Point3D;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.MeshView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

import java.net.URL;
import java.util.function.UnaryOperator;

public class rotation extends Application {

    public static void main(String args[]){
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        ObjModelImporter objImporter = new ObjModelImporter();
        try{
            URL modelUrl = this.getClass().getResource("/earth.obj");
            objImporter.read(modelUrl);
        } catch (ImportException e){

        }
        MeshView[] meshViews = objImporter.getImport();
        PhongMaterial texture = new PhongMaterial();
        texture.setDiffuseMap(new Image(getClass().getResource("/earth_texture.png").toExternalForm()));
        meshViews[0].setMaterial(texture);
        meshViews[0].setCursor(Cursor.CROSSHAIR);

        Group root = new Group(meshViews[0]);
        Pane pane = new Pane(root);
        meshViews[0].scaleXProperty().bind(Bindings.createDoubleBinding(
                () -> pane.getWidth()>pane.getHeight() ? pane.getHeight()/2 : pane.getWidth()/2,
                pane.heightProperty(), pane.widthProperty()
        ));
        meshViews[0].scaleYProperty().bind(Bindings.createDoubleBinding(
                () -> pane.getWidth()>pane.getHeight() ? pane.getHeight()/2 : pane.getWidth()/2,
                pane.heightProperty(), pane.widthProperty()
        ));
        meshViews[0].scaleZProperty().bind(Bindings.createDoubleBinding(
                () -> pane.getWidth()>pane.getHeight() ? pane.getHeight()/2 : pane.getWidth()/2,
                pane.heightProperty(), pane.widthProperty()
        ));
        meshViews[0].translateXProperty().bind(Bindings.createDoubleBinding(
                () -> pane.getWidth()/2,
                pane.widthProperty()
        ));
        meshViews[0].translateYProperty().bind(Bindings.createDoubleBinding(
                () -> pane.getHeight()/2,
                pane.heightProperty()
        ));


        meshViews[0].setRotationAxis(Rotate.Y_AXIS);

        pane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.RIGHT) {
                meshViews[0].setRotate(meshViews[0].getRotate() - 10);
            } else if (e.getCode() == KeyCode.LEFT) {
                meshViews[0].setRotate(meshViews[0].getRotate() + 10);
            }
        });


        HBox location = location(pane, meshViews[0]);
        BorderPane main = new BorderPane(pane, location, null, null, null);


        stage.setTitle("Globe Terrestre");
        stage.setMinWidth(800);
        stage.setMinHeight(600);
        stage.setScene(new Scene(main));
        stage.show();
    }

    private HBox location(Pane pane , MeshView meshView){
        //first Hbox
        HBox coordinates = new HBox();
        coordinates.setStyle("-fx-spacing: inherit; -fx-alignment: baseline-left;");

        Label text = new Label("Coordonnées de la localisation choisi sur le globe terrestre");

        Label lonLabel = new Label("Longitude (°) :");
        TextField lonField = new TextField();
        TextFormatter<Number> lonTextFormatter = lonTextFormatter();
        lonField.setTextFormatter(lonTextFormatter);
        lonField.setStyle("-fx-pref-width: 60; -fx-alignment: baseline-right;");

        Label latLabel = new Label("Latitude (°) :");
        TextField latField = new TextField();
        TextFormatter<Number> latTextFormatter = latTextFormatter();
        latField.setTextFormatter(latTextFormatter);
        latField.setStyle("-fx-pref-width: 60; -fx-alignment: baseline-right;");

        coordinates.getChildren().addAll(text, lonLabel, lonField, latLabel, latField);

        pane.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                pane.requestFocus();
            }
            if(e.isSecondaryButtonDown()){
                Point3D point = transformMouse(e.getSceneX(), e.getSceneY(), pane, -Angle.ofDeg(meshView.getRotate()));
                GeographicCoordinates coord = transformPoint(point.getX(), point.getY());
                lonTextFormatter.setValue(coord.lonDeg());
                latTextFormatter.setValue(coord.latDeg());
            }
        });
        return coordinates;
    }

    private Point3D transformMouse(double x, double y, Pane pane, double angle){
        double scaleX = pane.getWidth()/2;
        double scaleY = pane.getHeight()/2;
        double factor = pane.getWidth()>pane.getHeight() ? pane.getHeight()/2 : pane.getWidth()/2;

        double xA = (x - scaleX)/factor;
        double yA = (y - scaleY)/factor;

        double xB = xA;
        double yB = yA;
        double zB = -Math.sqrt(1-xA*xA-yA*yA);

        double xC = Math.cos(angle)*xB + Math.sin(angle)*zB;
        double yC = yB;
        double zC = -Math.sin(angle)*xB + Math.cos(angle)*zB;

        Point3D point = new Point3D(xC, yC, zC);
        return point;
    }

    private GeographicCoordinates transformPoint(double x, double y){
        double lat = Angle.toDeg(Math.asin(-y)) + 0.2;
        double lon = Angle.toDeg(Math.asin(-x/Math.cos(Angle.ofDeg(lat-0.2)))) - 2.8;
        return GeographicCoordinates.ofDeg(lon, lat);
    }

    private TextFormatter<Number> lonTextFormatter(){
        NumberStringConverter stringConverter = new NumberStringConverter("#0.00");

        UnaryOperator<TextFormatter.Change> lonFilter = (change -> {
            try {
                String newText =
                        change.getControlNewText();
                double newLonDeg =
                        stringConverter.fromString(newText).doubleValue();
                return GeographicCoordinates.isValidLonDeg(newLonDeg)
                        ? change
                        : null;
            } catch (Exception e) {
                return null;
            }
        });

        return new TextFormatter<>(stringConverter, 6.57, lonFilter);
    }

    private TextFormatter<Number> latTextFormatter(){
        NumberStringConverter stringConverter = new NumberStringConverter("#0.00");

        UnaryOperator<TextFormatter.Change> lonFilter = (change -> {
            try {
                String newText =
                        change.getControlNewText();
                double newLatDeg =
                        stringConverter.fromString(newText).doubleValue();
                return GeographicCoordinates.isValidLatDeg(newLatDeg)
                        ? change
                        : null;
            } catch (Exception e) {
                return null;
            }
        });

        return new TextFormatter<>(stringConverter, 42, lonFilter);
    }
}